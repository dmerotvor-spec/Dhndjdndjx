# /keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from datetime import datetime
from config import config

def get_menu_title(menu_name: str) -> str:
    """Формирует заголовок с новостным каналом и текущим временем."""
    now = datetime.now().strftime("%H:%M:%S")
    # Добавляем ссылку на новостной канал в заголовок
    channel_link = f"[{config.NEWS_CHANNEL_LINK.split('/')[-1]}]({config.NEWS_CHANNEL_LINK})"
    return f"**{menu_name}** | Новостной канал {channel_link} [{now}]"

def subscription_check_kb() -> InlineKeyboardMarkup:
    """Клавиатура с кнопкой для подписки на новостной канал."""
    kb = [
        [
            # Используем ссылку из конфига
            InlineKeyboardButton(text="➡️ Подписаться на @BetagramBotNews", url=config.NEWS_CHANNEL_LINK)
        ],
        [
            # Кнопка для повторной проверки после подписки
            InlineKeyboardButton(text="✅ Я подписался (проверить)", callback_data="check_subscription")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def main_menu_kb() -> InlineKeyboardMarkup:
    # ... (Остальной код main_menu_kb и других клавиатур остается без изменений)
    kb = [
        [
            InlineKeyboardButton(text="👤 Мой Профиль", callback_data="profile_menu"),
            InlineKeyboardButton(text="⭐ Баланс (STARS)", callback_data="balance_menu"),
        ],
        [
            InlineKeyboardButton(text="💎 Юзернеймы", callback_data="usernames_menu"),
            InlineKeyboardButton(text="🎁 Подарки", callback_data="gifts_menu"),
        ],
        [
            InlineKeyboardButton(text="💬 Общий Чат", callback_data="chat_enter"),
            InlineKeyboardButton(text="🔎 Поиск", callback_data="search_start"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)
# ... (Остальные клавиатуры profile_menu_kb, balance_menu_kb, admin_menu_kb)