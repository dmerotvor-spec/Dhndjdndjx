# /config.py
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List

class Settings(BaseSettings):
    # Настройки Telegram
    BOT_TOKEN: str = "5002192625:AAHJ-cZ8XY-YjfGIc824R6MCQrs_78cViSQ/test" # ТОКЕН
    ADMIN_ID: int = 5000708127 # ID АДМИНА
    LOG_CHANNEL_ID: int = -1005000351702 # ID КАНАЛА ЛОГОВ
    
    # Настройки Канала для Подписки
    NEWS_CHANNEL_ID: int = -1005000252805 # ID КАНАЛА ДЛЯ ПОДПИСКИ
    NEWS_CHANNEL_LINK: str = "https://t.me/BetagramBotNews" # ССЫЛКА НА КАНАЛ
    
    # Настройки Базы Данных (Используйте свои, если PostgreSQL не локально)
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_USER: str = "betagram_user"
    DB_PASS: str = "secure_password"
    DB_NAME: str = "betagram_db"

    @property
    def db_url(self) -> str:
        return f"postgresql+asyncpg://{self.DB_USER}:{self.DB_PASS}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

config = Settings()

# --- Константы Бота ---
PREMIUM_PRICE = 150000 
TON_EXCHANGE_RATE = 10 
USERNAME_PRICING = {
    'SHORT': 1000,
    'LONG': 0    
}