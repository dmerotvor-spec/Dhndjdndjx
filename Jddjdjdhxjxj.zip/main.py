# /main.py
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from aiogram.client.session.aiohttp import AiohttpSession
from sqlalchemy.ext.asyncio import AsyncSession
from config import config
from database import init_db, AsyncSessionLocal
from handlers import router as handlers_router # Импорт роутера из handlers.py

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- МИДДЛВАРА ДЛЯ ВСТРАИВАНИЯ СЕССИИ DB ---

class DatabaseMiddleware:
    """Промежуточное ПО для передачи сессии БД в хендлеры."""
    def __init__(self, session_pool):
        self.session_pool = session_pool

    async def __call__(self, handler, event, data):
        async with self.session_pool() as session:
            data["session"] = session
            return await handler(event, data)

# --- УСТАНОВКА КОМАНД ---

async def set_commands(bot: Bot):
    commands = [
        BotCommand(command="/start", description="Главное меню"),
        BotCommand(command="/admin", description="Панель администратора"),
    ]
    await bot.set_my_commands(commands)
    logger.info("Команды бота установлены.")

# --- ОСНОВНАЯ ФУНКЦИЯ ЗАПУСКА ---

async def main():
    logger.info("Запуск BetaGram...")
    
    # 1. Инициализация БД (создание таблиц)
    await init_db()
    logger.info("База данных инициализирована.")
    
    # 2. Инициализация Бота и Диспетчера
    session = AiohttpSession()
    bot = Bot(token=config.BOT_TOKEN, session=session)
    dp = Dispatcher(storage=MemoryStorage())
    
    # 3. Регистрация Middleware
    # Middleware для передачи сессии БД в хендлеры
    dp.update.middleware(DatabaseMiddleware(AsyncSessionLocal)) 
    
    # 4. Регистрация Роутеров
    dp.include_router(handlers_router)
    
    # 5. Установка команд
    await set_commands(bot)
    
    # 6. Запуск обработки событий
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен вручную.")
    except Exception as e:
        logger.error(f"Критическая ошибка запуска: {e}")