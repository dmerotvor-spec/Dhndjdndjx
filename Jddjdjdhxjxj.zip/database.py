# /database.py
from sqlalchemy import BigInteger, Column, String, Integer, DateTime, Boolean, Numeric, ForeignKey, Enum, select
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from datetime import datetime
import enum
from config import config

Base = declarative_base()

class UserStatus(enum.Enum):
    NORMAL = "Обычный"
    PREMIUM = "Премиум"

# --- МОДЕЛИ ДАННЫХ (Схема БД) ---

class User(Base):
    __tablename__ = "users"
    
    tg_id = Column(BigInteger, primary_key=True, unique=True, index=True)
    username = Column(String, default="ID пользователя")
    first_name = Column(String, nullable=True)
    description = Column(String, nullable=True)
    phone_number = Column(String, nullable=True)
    
    balance_stars = Column(BigInteger, default=0)
    balance_ton = Column(Numeric, default=0.0)
    status = Column(Enum(UserStatus), default=UserStatus.NORMAL)
    reg_date = Column(DateTime, default=datetime.utcnow)
    is_banned = Column(Boolean, default=False)
    
    usernames = relationship("UserUsername", back_populates="owner")
    
class UserUsername(Base):
    __tablename__ = "user_usernames"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(ForeignKey("users.tg_id", ondelete="CASCADE"), nullable=False)
    username = Column(String, unique=True, nullable=False)
    is_primary = Column(Boolean, default=False)
    is_on_market = Column(Boolean, default=False)
    price_ton = Column(Numeric, nullable=True)
    is_in_blockchain = Column(Boolean, default=False)
    
    owner = relationship("User", back_populates="usernames")

# (Модели для подарков, чата и т.д. опущены для минимального рабочего примера)

# --- УПРАВЛЕНИЕ БАЗОЙ ДАННЫХ ---

engine = create_async_engine(config.db_url, echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def init_db():
    """Создает таблицы в базе данных."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def get_user_or_create(tg_id: int, tg_username: str) -> User:
    """Получает пользователя по ID или создает нового."""
    async with AsyncSessionLocal() as session:
        user = await session.get(User, tg_id)
        if user is None:
            user = User(
                tg_id=tg_id, 
                username=tg_username if tg_username else str(tg_id),
                first_name=tg_username # Временно используем TG username как имя
            )
            session.add(user)
            await session.commit()
            return user
        return user