# /handlers.py
from aiogram import Router, F, types
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery, ChatMemberStatus # Добавлен ChatMemberStatus
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_user_or_create, User, AsyncSessionLocal
from keyboards import get_menu_title, main_menu_kb, profile_menu_kb, balance_menu_kb, admin_menu_kb, subscription_check_kb # Импорт новой KB
from config import config, PREMIUM_PRICE, TON_EXCHANGE_RATE
from datetime import datetime
import logging

router = Router()
logger = logging.getLogger(__name__)

# ... (Остальной код FSM States и log_action)

# --- НОВАЯ: ФУНКЦИЯ ПРОВЕРКИ ПОДПИСКИ ---

async def is_subscribed(bot: types.Bot, user_id: int) -> bool:
    """Проверяет, является ли пользователь участником канала NEWS_CHANNEL_ID."""
    try:
        member = await bot.get_chat_member(chat_id=config.NEWS_CHANNEL_ID, user_id=user_id)
        
        # Статусы, которые считаются "подпиской": Creator, Administrator, Member
        return member.status in [
            ChatMemberStatus.CREATOR, 
            ChatMemberStatus.ADMINISTRATOR, 
            ChatMemberStatus.MEMBER
        ]
            
    except Exception as e:
        logger.error(f"Ошибка проверки подписки ({user_id}): {e}")
        # Если бот не является админом в канале или произошла другая ошибка,
        # возвращаем False, чтобы потребовать подписку.
        return False

# --- 1. ОБЩИЕ КОМАНДЫ И МЕНЮ ---

async def show_main_menu(message: Message | CallbackQuery, state: FSMContext, session: AsyncSession, bot: types.Bot):
    """Отображает главное меню после успешной подписки/проверки."""
    await state.clear()
    
    tg_user = message.from_user
    user = await get_user_or_create(tg_user.id, tg_user.username)
    
    text = get_menu_title("🌟 Главное Меню BetaGram")
    text += f"\n\nДобро пожаловать, **{user.username}**! Выберите действие."
    
    if isinstance(message, Message):
        await message.answer(text, reply_markup=main_menu_kb(), parse_mode="Markdown")
    else:
        await message.message.edit_text(text, reply_markup=main_menu_kb(), parse_mode="Markdown")
        await message.answer()
        
    # Логирование регистрации только при первом входе
    if user.reg_date == user.reg_date: # Простая проверка на новый объект
         await log_action(bot, user.tg_id, user.username, "Доступ разрешен", "Пользователь вошел в меню")


@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext, bot: types.Bot, session: AsyncSession):
    """Обработчик /start с проверкой подписки."""
    await state.clear()
    
    if await is_subscribed(bot, message.from_user.id):
        # Пользователь подписан -> Показываем главное меню
        await show_main_menu(message, state, session, bot)
    else:
        # Не подписан -> Просим подписаться
        text = get_menu_title("🔒 Доступ ограничен")
        text += f"\n\nДля использования бота **BetaGram** необходимо подписаться на наш новостной канал **@BetagramBotNews**."
        
        await message.answer(text, reply_markup=subscription_check_kb(), parse_mode="Markdown")

@router.callback_query(F.data == "check_subscription")
async def cb_check_subscription(callback: CallbackQuery, state: FSMContext, bot: types.Bot, session: AsyncSession):
    """Повторная проверка подписки по кнопке."""
    if await is_subscribed(bot, callback.from_user.id):
        # Пользователь подписан -> Показываем главное меню
        await show_main_menu(callback, state, session, bot)
    else:
        # Все еще не подписан -> Выдаем предупреждение
        await callback.answer("❌ Вы еще не подписались или не нажали кнопку 'Я подписался' в канале.", show_alert=True)
        await callback.message.edit_text(
            get_menu_title("🔒 Доступ ограничен") + "\n\nПожалуйста, подпишитесь на канал, прежде чем продолжить.",
            reply_markup=subscription_check_kb(),
            parse_mode="Markdown"
        )

@router.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery, state: FSMContext, session: AsyncSession, bot: types.Bot):
    """Возврат в главное меню (редактирование сообщения)."""
    # Всегда проверяем подписку при входе в основное меню
    if not await is_subscribed(bot, callback.from_user.id):
        return await cb_check_subscription(callback, state, bot, session) # Перенаправляем на проверку
        
    await state.clear()
    text = get_menu_title("🌟 Главное Меню BetaGram")
    text += f"\n\nВы вернулись в главное меню. Выберите действие."
    await callback.message.edit_text(text, reply_markup=main_menu_kb(), parse_mode="Markdown")
    await callback.answer()

# ... (Остальной код Хендлеров: Профиль, Баланс, Админ-панель остается без изменений)